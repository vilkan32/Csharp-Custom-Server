﻿namespace SharedTrip
{
    public class DatabaseConfiguration
    {
        public const string ConnectionString =
            @"Server=DESKTOP-SLBT47B\SQLEXPRESS;Database=BrandNewDatabase;Integrated Security=True;";
    }
}